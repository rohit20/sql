--1. all databasaes in ur system
 select * from sys.databases;

 --know current tables present in database
 select * from sys.tables where object_id=object_id('TestResthrow_164307');

 --2. change active database
 use master

 --3. know current active database name
 select DB_Name()

 --4. change active database
 use Training
 use Northwind

 --5. know detail info about table employee
 exec sp_help 'Employee'

 --6. change active database
 use master

 -- get details of table spt_fallback_db
 exec sp_help 'spt_fallback_db'

 --7. get current version
 select @@version

 --8. get current date
 select GETDATE()

 --9.
 use Northwind
 select * from sys.tables
 exec sp_help 'products'
 exec sp_help 'Orders'
 exec sp_help 'Orderdetails'
 exec sp_help 'Employees'

--10


--1.3
use Training_24oct18_Pune
create table customer_164307
(
customerid int unique not null,
customerName varchar(20) not null,
Address1   varchar(30),
Address2   varchar(30),
contactNumber varchar(12) not null,
postalcode varchar(10)
)


--2.

CREATE TABLE Employee_164307
(
EmployeeId INT not null PRIMARY KEY,
Name NVARCHAR(255) null
); 

--3.

CREATE TABLE contractors_164307
(
contractorId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) null
); 

--4. 
USE Training_24oct18_Pune;
CREATE TABLE dbo.Testthrow_164307
(
ID INT PRIMARY KEY
);

select * from contractors_164307;

--5. create a user defined data type called region,which would store a character string of size 15
CREATE Type Region164307 from varchar(15)

--6. Create a default which would store the value 'NA' ('North America')
Create Default northAmerica307 as 'NA';

--7. bind default to alias
exec sp_bindefault northAmerica307,Region164307;

--8. modifyv the table customers to add the column called customer_region which would be of data type: region164307

alter table customer_164307 add customer_region region;

select * from customer_164307;

sp_help customer_164307;

--9. add the column to the customer table gender char (1)
   alter table customer_164307 add Gender1 char(1);

   sp_help customer_164307;

--10. using alter table statement add a constraint to the gender column such that it would not accept any other values except 'M','F','T'
alter table customer_164307 add constraint ck_gender307 check(Gender1 in('m','f','t'));                                                 

sp_help customer_164307


--11. create table orders_164307
 create table orders_164307
 (ordersId int not null identity(1000,1),
 customerId int not null,
 customerNme varchar(20) not null,
 ordersdate datetime,
 order_state char(1) constraint ck_orderstate307  check(order_state in ('p','c')));
 
 sp_help orders_164307; 

 select * from customer_164307

 --12. add referential integrity constraint for orders & customer tables through customeId with the name fk_custorders

 alter table customer_164307 add constraint  pk2_primarykey164307 primary key(customerId);
 alter table orders_164307 add constraint pk1_primarykey164307 primary key(customerId);
 alter table orders_164307 add constraint fk_foreignkey164307 foreign key(customerId) references customer_164307(customerId);

 sp_help orders _164307

 --13.creating sequence numbers 
 --task1 create sequence
 CREATE SEQUENCE Idsequence_164307 AS INT 
 START WITH 10000
 INCREMENT BY 1;

 --TASK2 USING THE SEQUENCE TO INSERT NEW ROWS
 INSERT INTO Employee_164307 (EmployeeId,Name) VALUES (Next VALUE FOR Idsequence_164307, 'shashank') 
 INSERT INTO contractors_164307 (contractorId,Name) VALUES (Next VALUE FOR Idsequence_164307, 'aditya')

 select * from Employee_164307;

 select * from contractors_164307;


 use training;
 --1.4 simple queries and merge statement

 --1. list out student_code,student_name and separtment_code of every student
 select * from Student_Master;
 select stud_code,stud_name,dept_code from Student_Master;

 --2. do the same for all the staff's
 select * from staff_master;
 select staff_code,staff_name,dept_code from staff_master;

 --3. retrieve the details (name,salary and dept code) of the employees who are working in department 20,30,40
 select * from staff_master; 
 select staff_name,salary,dept_code from staff_master 
where (dept_code=20 or dept_code=30 or dept_code=40);

--4.display student_code,subjects and total_marksfor every student. Total_marks will
-- calculate as subject1 + subject2 + subject3 from from student_marks. The records
-- should be dispalyed in the descending order of total score

select * from student_marks;
  
--5.List out all the books which starts with 'An', along with price

SELECT * FROM BOOK_MASTER;
alter table book_master add bookPrice int;
update book_master set bookPrice=320 where book_code= 10000010;
select book_code,bookPrice from Book_Master where book_name like 'An%';

--6. List out all the departments codes in which students have joined this year

select * from student_marks;

select * from student_master;
 
select dept_code from staff_master inner join student_master
where student_code=student_master.student_code and staff_master.student_year=2018;

--7. Display name and date of birth of students where date of birth must be displayed
-- the format similar to "January,12 1981" for those who were born on saturday or
-- sunday

select * from student_master;
select student_name,DATETIME(month,student_dob) + ',' +format(student_dob,'dd yyy') as dob_of_student fom
student_master where (datename(dw,stdent_dob)='saturday' or (datename(dw,student_dob)='sunday'));

-8. List out a report like this staffcode staffname  dept code date of joining  no. of years in the company

select * from staff_master;
select staff_code,staff_name,dept_code,hiredate from staff_master;  

--9. List out all staffs who have joined before jan 2000
 select * from staff_master
 where hiredate< '2000-01-01';

 --10. Write a query which will display studenName,deptCode  and dob of all
 -- students who are born betweeen january 1,1981 and march 31,1983
  
  select * from student_master;
  select stud_name,dept_code,stud_dob from student_master 
  where stud_dob between '1981-01-10' and '1982-03-31'; 

  --11. List out all student codes who did not appear in the exam subject2
   select * from student_marks;
   select stud_code from student_marks where subject2 is null;

   --working with merge

CREATE TABLE products_164307
{
productId INT PRIMARY KEY,
productName INT PRIMARY KEY,
productName VARCHAR(100)
Rate Money
};

INSERT INTO products_164307 VALUES(1,'Tea',10.00),(2,'coffee',20.00),(3,'Muffin',30.00),(4,'Biscuit',40.00);

INSERT INTO updatedProducts_164307 VALUES(1,'Tea',10.00),(2,'coffee',25.00),(3,'Muffin',35.00),(5,'pizza',60.00);

MERGE products_164307 AS TARGET
USING updatedProducts_164307 AS SOURCE
ON( TARGET,productID = source.PRODUCT.ID)
WHEN MATCHED AND TARGET.ProductName <> SOURCE.productName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.productName = SOURCE.productName,
TARGET.Rate = SOURCE.Rate
WHEN NOT MATCHED BY TARGET THEN
INSERT(productID,productName,Rate)
VALUES (SOURCE.productID, SOURCE.productName, SOURCE.Rate)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT Section,
DELETED.productID AS TargetedProductID,
DELETED.productName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.productID AS SourceProductID,
INSERTED.productName AS SourceProductName,
INSERTED.Rate AS SourceRate,

SELECT @@ROWCOUNT

SELECT * FROM products_164307;

SELECT * FROM updatedProducts_164307;




--(1.5)

--1. Write a query which displays Staff Name, Department Code, Department Name, and
--Salary for all staff who earns more than 20000.
--use training

select * from staff;
select * from dept;

select * from staff_master;
select * from department_master;

select staff_master.staff_name,staff_master.dept_code,department_master.dept_name,staff_master.staff_sal 
from staff_master inner join department_master on staff_master.dept_code=department_master.dept_code 
where staff_master.staff_sal>20000;

--2. Write a query to display Staff Name, Department Code, and Department Name for all
--staff who do not work in Department code 10

select staff_master.staff_name,staff_master.dept_code,department_master.dept_name
from staff_master inner join department_master on staff_master.dept_code=department_master.dept_code 
where staff_master.dept_code<>10;

--3. Print out a report like this
   --Book Name No of times issued
   --Let us C 12
   --Linux Internals 9

select * from book_transaction;
select * from book_master;

select bm.book_name,count(*) as no_of_times_issued 
from book_transaction bk inner join book_master bm on ( bk.book_code=bm.book_code)
group by bm.book_name;

--4. List out number of students joined each department last year. The report should be
--displayed like this
--Physics 12
--Chemistry 40

select * from department_master;
select * from student_master;

select dm.dept_name,count(*) as no_of_student_joined
from department_master dm inner join student_master sm on (dm.dept_code=sm.dept_code)
group by dm.dept_name

--5.) List out a report like this Staff Code Staff Name Manager Code Manager Name

select * from staff_master;

select sm.staff_code,sm.staff_name,ms.mgr_code,ms.mgr_name
from staff_master sm inner join staff_master ms on (sm.staff_code=ms.staff_code)

--6.) Display the Staff Name, Hire date and day of the week on which staff was hired.
    --Label the column as DAY. Order the result by the day of the week starting with Monday.

select * from staff_master;


select staff_name,hire_date,datename(dw,hire_date) from staff_master
 order by hire_date;

--7.) Display Staff Code, Staff Name, and Department Name for those who have taken
     --more than one book.

select * from staff_master;

select * from department_master;
select * from book_transaction;
select sm.staff_code,sm.staff_name,dm.dept_name 
from book_transaction bt
inner join 
staff_master sm
on (bt.staff_code=sm.staff_code)
inner join 
department_master dm 
on (sm.dept_code=dm.dept_code)
group by sm.staff_code,sm.staff_name,dm.dept_name
having count(bt.staff_code)>1 


--8.) List out the names of all student code whose score in subject1 is equal to the
    --highest score

select * from student_master
select * from student_marks


select sm.student_name
from student_master sm inner join student_marks ms on (sm.student_code=ms.student_code)
where ms.subject1>ms.subject2 and ms.subject1>ms.subject3



--9.) Modify the above query to display student names along with the codes.


select sm.student_name,sm.student_code
from student_master sm inner join student_marks ms on (sm.student_code=ms.student_code)
where ms.subject1>ms.subject2 and ms.subject1>ms.subject3


--10.)List out the names of all the books along with the author name, book code and
     --category which have not been issued at all. Try solving this question using EXISTS

select * from book_master
select * from book_transaction

select book_name,book_pub_author,book_code,BOOK_category 
from book_master as b1
where EXISTS(select book_code from book_transaction where book_issue_datE!=NULL)

--11.) List out the code and names of all staff and students belonging to department 20.

select * from staff_master 
select * from student_master

select staff_code,staff_name
from staff_master where dept_code=20
UNION
select student_code,student_name
from student_master where dept_code=20

--12.) List out all the students who have not appeared for exams this year.

select * from student_marks
select * from student_master
select student_name 
from student_master sm inner join student_marks ms 
on (sm.student_code=ms.student_code) where student_year<>datename(yy,getdate())



--13.)List out all the student codes who have never taken books
select * from student_master
select * from book_transaction

select stud_code 
from student_master
Except (select stud_code 
from book_transaction where stud_code is not null )

--14.) Add the following records to the Customers Table , created in our earlier exercises

 create table Customers_1996(
 Customer_id varchar(50),
 Customer_name varchar(50),
 Address1 varchar(50),
 Address2 varchar(50),
 Contact varchar(50),
 Postal_Code varchar(50),
 Region varchar(50),
 Gender varchar(50) 
 )

 insert into Customers_1996 values('ALFKI','AlfredsFutterkiste','ObereStr. 57','Berlin,Germany','030-0074321','12209',NULL,NULL)
 insert into Customers_1996 values('ANATR','Ana TrujilloEmparedados yhelados','Avda dela Constituci�n 2222','M�xico D.F.Mexico','55554729','5021',NULL,NULL);
 insert into Customers_1996 values('ANTON','Antonio Moreno Taquer�a','Mataderos 2312','M�xico D.F.,Mexico','5-555-3932','5023',NULL,NULL),
('AROUT','Around the Horn','120 Hanover Sq.','London,UK','171-555-7788','WA11DP',NULL,NULL),
('BERGS','Berglundssnabbk�p','Berguvsv �gen 8','Lule�,Sweden','0921-123465','S-95822',NULL,NULL),
('BLAUS','Blauer SeeDelikatessen','Forsterstr. 57','Mannheim,Germany','0621-08460','68306',NULL,NULL),
('BLONP','Blondesddslp�reet fils','24, placeKl�ber','Strasbourg,France','88-60-15-31','67000',NULL,NULL),
('BOLID','B�lidoComidaspreparadas','C/Araquil,67','Madrid,Spain','91-555-22-82','28023','EU',NULL),
('BONAP','Bon app','12, ruedesBouchers','Marseille,France','91-24-45-40','13008',NULL,NULL),
('BOTTM','Bottom-DollarMarkets','23 Tsawassen Blvd.','Tsawassen,Canada','604-555-4729','T2F8M4','BC',NULL);

select * from Customers_1996 

--15.) Replace the contact number of Customer id ANATR to (604) 3332345.

Update Customers_1996 set contact='(604) 3332345'
where Customer_id='ANATR';

--16.) Update the Address and Region of Customer BOTTM to the following
       --19/2 12th Block, Spring Fields.
       --Ireland - UK
       --Region - EU

Update Customers_1996 set Address1='19/2 12th Block, Spring Fields.',Address2='Ireland - UK',
Region='EU' where Customer_id='BOTTM'

select * from Customers_1996

--17.) Insert the following records in the Orders table. The Order id should be automatically generated
     --Save the commands in a script file (Script file has a .sql extension)

Create table Orders_1996(
Orders_id int CONSTRAINT Ord_123 NOT NULL Identity(1,1) ,
Customer_id varchar(50),
Order_date date,
Order_State char(10)
);

insert into Orders_1996 values('AROUT','4-Jul-96','P')

select * from Orders_1996

insert into  Orders_1996 values('ALFKI','5-Jul-96','C'),
('BLONP','8-Jul-96','P'),('ANTON','8-Jul-96','P'),('ANTON','9-Jul-96','P'),
('BOTTM','10-Jul-96','C'),('BONAP','11-Jul-96','P'),('ANATR','12-Jul-96','P'),
('BLAUS','15-Jul-96','C'),('HILAA','16-Jul-96','P');


--18.) Delete all the Customers whose Orders have been cleared.

Delete from  Customers_1996
where Customer_id in
(
select Customer_id 
from Orders_1996
where Order_state='C'
)


select * from Customers_1996

--19.) Remove all the records from the table using the truncate command. Return the script
     --to populate the records once again

Truncate table Customers_1996

select * from  Customers_1996

--20.) Change the order status to C, for all orders before `15th July.

Update Orders_1996 set Order_state='C'
where  Order_date<'15-Jul-1996'

select * from Orders_1996





--1.6 Indexes and Views
        
--1. Create a Unique index on Department Name for Department master Table.

select * from department_master

Create Unique Index dept_123
on department_master(dept_name)

--Try inserting the following values and observe the output

insert into department_master values(100,'Home Science'),(200,'Home Science'),
(300,NULL),(400,NULL)

  --Answer(Error Message)-Violation of PRIMARY KEY constraint 'PK__Departme__8985FE74F898DF29'. Cannot insert duplicate key in object 'university.Department_Master'. The duplicate key value is (100).
  --The statement has been terminated.

--3) Create a non-clustered index for Book_Trans table on the following columns
    --Book_code, Staff_name, student name, date of issue. Try adding some values.
    --Do you experience any difficulties?

select * from book_transaction

Create nonclustered index booktran_123 on 
book_transaction bt inner join staff_master sm on (bt.staff_code=sm.staff_code) 
include (bt.book_code,sm.staff_name,bt.issue_date)
inner join
student_master ms on (ms.stud_code=bt.stud_code)
include (ms.stud_name)



--4) List the indexes created in the previous questions, from the sysindexes table.
 
 select * from sys.indexes
 where object_id=object_id('book_transaction')

 select * from sys.indexes
 where object_id=object_id('student_master')

--5. Create a View with the name StaffDetails_view with the following column name
--Staff Code, Staff Name, Department Name, Desig Name salary

select * from desig_master
select * from staff_master

create view StaffDetails123_view as
select sm.staff_code, sm.staff_name,dm.dept_name,sm.staff_sal,md.design_name
from staff_master sm inner join department_master dm on (sm.dept_code=dm.dept_code)
inner join desig_master md
on (md.design_code=sm.design_code) 

--6. Try inserting some records in the view; Are you able to add records? Why not? Write
   --your answers here.

    insert into StaffDetails123_view values(1000,'Raju','Analyst',20000)  
    --Ans=View or function 'StaffDetails123_view' is not updatable because the modification affects multiple base tables.

--7. Working with Filtered Index � The following Filtered Index created on
--Production.BillOfMaterials table, cover queries that return the columns defined in
--The index and that select only rows with a non-NULL value for EndDate.

USE Adventure Works;
GO
CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL;
GO

--8. View the definition of the view using the following syntax

Sp_help StaffDetails123_view

--9. Using the view , List out all the staffs who have joined in the month of June

select sm.staff_name
from StaffDetails123_view sd inner join staff_master sm on (sd.staff_code=sm.staff_code)
where datename(month,sm.hire_date)='June';

--10. Create a non-clustered column store index on EmployeeID of Employees table
  create nonclustered columnstore index emp_123 on employees(employeeid)
   


   --1.7 Procedures and Exception Handling in SQL server 

/*1. Write a procedure that accept Staff_Code and updates the salary and store the old
salary details in Staff_Master_Back (Staff_Master_Back has the same structure
without any constraint) table. The procedure should return the updated salary as the
return value
Exp< 2 then no Update
Exp>= 2 and <= 5 then 20% of salary
Exp> 5 then 25% of salary
*/
create table staff_master_back_123
 (
 Staff_code int,
 Staff_name varchar(50) not null,
 Design_code int,
 Dept_code	int,
 Hire_date	datetime,
 Staff_dob	datetime,
 Staff_address	varchar(240),
 Mgr_code int,
 Staff_sal decimal(10,2)
 );


 select * from staff_master_bacK_123;
 insert into staff_master_back_123 values
 (204,'Smith',101,20,24-07-2010,25-10-1979,'t village',9,'90000'),
 (202,'Warner',100,30,10-07-2012,29-01-1996,'gurgaon',16,'70000'),
 (203,'Smithy',102,20,19-07-2010,19-10-1979,'ashok van',16,'160000'),
 (201,'marcus',102,40,20-07-2003,29-08-1987,'t village',25,'75000');

 alter table staff_master add exper int; 
 update staff_master 
 set exper=datediff(yy,hiredate,getdate());

 select * from staff_master

 
 alter table staff_master alter column salary int;


  create procedure expr @staff_name varchar(20) as
 begin
    declare @experience int;
	set @experience=(select experience from staff_master where staff_name=@staff_name);
	if(@experience<2)
	begin
	update staff_master set salary=(salary*1) where staff_name=@staff_name;
	end
	else 
	begin
	if(@experience between 1 and 6)
	begin
	update staff_master set salary=(salary+salary*0.2) 
	where staff_name=@staff_name;
	end
	else
	begin
	update staff_master set salary=(salary+salary*0.25)
	where staff_name=@staff_name;
	end
	end
 end;

 select * from staff_master;
 exec expr 'kirti';
 exec expr 'marcus';

/*2. Write a procedure to insert details into Book_Transaction table. Procedure should
accept the book code and staff/student code. Date of issue is current date and the
expected return date should be 10 days from the current date. If the expected return
date falls on Saturday or Sunday, then it should be the next working day. Suitable
exceptions should be handled
*/
 select * from book_transaction
 alter table book_transaction alter column issue_date date;
 alter table book_transaction alter column actual_return_date date;


  create procedure bookrs @book_code int, @stud_code int as
 begin
	if exists(select book_code from book_transaction where book_code=@book_code)
	begin
	raiserror('Book is unavailable',12,1,@book_code);
	end
	else
	begin try
	begin
	insert into book_transaction(book_code,stud_code,issue_date,actual_return_date)
	values (@book_code,@stud_code,getdate(),dateadd(day,10,getdate()));
	end
	begin
	update book_transaction set actual_return_date=(dateadd(day,12,getdate()))
	where datename(dw,actual_return_date)='saturday';
	end
	begin
	update book_transaction set actual_return_date=(dateadd(day,11,getdate()))
	where datename(dw,actual_return_date)='sunday'
	end
	end try
	begin catch
	throw
	end catch
 end 

 --3. Modify question 1 and display the results by specifying With result sets.

 create procedure ver @staff_name varchar(20) as
 begin
    declare @experience int;
	set @experience=(select experience from staff_master where staff_name=@staff_name);
	if(@experience<2)
	begin
	update staff_master set salary=(salary*1) where staff_name=@staff_name;
	end
	else 
	begin
	if(@experience between 1 and 6)
	begin
	update staff_master set salary=(salary+salary*0.2) 
	where staff_name=@staff_name;
	end
	else
	begin
	update staff_master set salary=(salary+salary*0.25)
	where staff_name=@staff_name;
	end
	end
 end;

exe ver 'Udas'
 with result sets
 (
 (staff_code int not null,
  salary int not null)
 )

/*4. Create a procedure that accepts the book code as parameter from the user. Display
the details of the students/staff that have borrowed that book and has not returned
the same. The following details should be displayed
Student/StaffCode Student/StaffName IssueDate Designation
ExpectedRet_Date
*/
 create procedure bookdetail123 @book_code int
 as
 begin
	select * from staff_master sm full join book_transaction bt
	on(sm.staff_code=bt.staff_code)
	where bt.book_code=@book_code;
end 

exec bookdetail123 3;

/*5. Write a procedure to update the marks details in the Student_marks table. The
following is the logic.
� The procedure should accept student code , and marks as input parameter
� Year should be the current year.
� Student code cannot be null, but marks can be null.
� Student code should exist in the student master.
� The entering record should be unique ,i.e. no previous record should exist
� Suitable exceptions should be raised and procedure should return -1.
� IF the data is correct, it should be added in the Student marks table and a
success value of 0 should be returned
*/
create procedure stud1 @student_code int, @subject1 int
as
declare @year int
begin
set @year=(select student_year from student_marks as sm 
		   where sm.student_code=@student_code);
if(@year!=2018)
	begin
		raiserror('invalid year',12,1,@year);
	end
else
	begin
		if(@student_code is null)
			begin
				raiserror('Student code can not be null',12,1);
			end
		else
			begin
				if(not exists(select * from student_master where student_code=@student_code))
					begin
						raiserror('Student does not exist in records',11,1);
					end
				else
					begin
						update student_marks set subject1=@subject1 where student_code=@student_code;
					end 
			end
	end
end;
select * from student_marks 

exec stud1 1001,55;





--2.1 Transact-SQL Statements
    
  --1.) List the empno, name and Department No of the employees who have got
      --experience of more than 18 years.

	select *  from staff_master
	select * from department_master
    select sm.staff_name,sm.staff_code,dm.dept_code 
	from staff_master sm inner join department_master dm on(sm.dept_code=dm.dept_code) 
	where sm.experience>18

--2. Display the name and salary of the staff. Salary should be represented as X. Each X
    --represents a 1000 in salary. It is assumed that a staff�s salary to be multiples of 1000,  
    --for example a salary of 5000 is represented as XXXXX Sample Output
    --JOHN 10000 XXXXXXXXXX
    --ALLEN 12000 XXXXXXXXXXXX

     select *  from staff_master
     select staff_name,replicate('X',(staff_sal/1000)) as salary from staff_master

--3. List out all the book code and library member codes whose return is still pending
     select * from book_transaction
     select * from library

	 select book_code ,staff_code,student_code from book_transaction where book_actual_return_date is null

--4. List all the staff�s whose birthday falls on the current month

   select * from staff_master
   select * from staff_master where datename(month,staff_dob)=datename(month,getdate())

--5. How many books are stocked in the library?
select * from book_master
select count(*) as book_stocked from book_master

--6. How many books are there for topics Physics and Chemistry?
select * from book_master
select count(*) from book_master where book_category like 'Physics' or  book_category like 'Chemistry'


--7. How many members are expected to return their books today?
     select * from book_transaction
     select count(*) from book_transaction where book_expected_return_date=getdate()

/*8. Display the Highest, Lowest, Total & Average salary of all staff. Label the columns
  Maximum, Minimum, Total and Average respectively. Round the result to nearest
  whole number*/

   select max(staff_sal) as maximum,min(staff_sal) as minimum,sum(staff_sal) as total,avg(staff_sal) as average from staff_master
   select ceiling(max(staff_sal)),ceiling(min(staff_sal)),ceiling(sum(staff_sal)),ceiling(avg(staff_sal))  from staff_master

--9. How many staffs are managers�?

   select * from staff_master
   select count(*) as Total_no_of_managers from staff_master where mgr_code is not null

/*10. List out year wise total students passed. The report should be as given below. A
student is considered to be passed only when he scores 60 and above in all 3
subjects individually
Year No of students passed*/

select student_year as passing_year,count(*) as no_of_passing_year 
from student_marks 
where (subject1>=60 and subject2>=60 and subject3>=60 ) 
group by student_year

--11.List out all the departments which is having a headcount of more than 10

select * from student_master
select * from department_master

select count(*) as num_students from student_master s inner join department_master d on(s.dept_code=d.dept_code) group by d.dept_name having count(s.student_code) >10

--12. List the total cost of library inventory ( sum of prices of all books )

     select sum(bookprice) as total_cost from Book_Master

--13. List out category wise count of books costing more than Rs 1000 /-
   
      select * from book_master
      select book_category,count(*) as book from book_master group by book_category,bookprice having bookprice >1000

--14 How many students have joined in Physics dept (dept code is 10) last year?

select * from student_master
select * from  department_master
select * from student_marks
select * from staff_master

select count (*) from (student_master sm inner join department_master dm on (sm.dept_code=dm.dept_code))
inner join student_marks ms on (sm.stud_code=ms.stud_code)
where sm.dept_code=10 and dm.dept_name='Physics' and ms.stud_year=datename(yy,getdate())
-------------------------------------------------------------------------------------------------------------------
--2.2 Data Retrieval - Joins, Subqueries, SET Operators and DML

/* 1. Write a query that displays Staff Name, Salary, and Grade of all staff. Grade depends
     on the following table.

Salary                     Grade
Salary >=50000               A
Salary >= 25000 < 50000      B
Salary>=10000 < 25000        C
*/
   select staff_name,staff_sal,
     case
     when staff_sal >=50000 THEN 'A'
     when staff_sal >=25000 and staff_sal <50000 THEN 'B'
     when staff_sal >=10000 and staff_sal <25000 THEN 'C'
     ELSE 'D'
     end
     as grade
   from staff_master

/* 2. Generate a report which contains the following information.
Staff Code, Staff Name, Designation, Department, Book Code, Book Name,
Author, Fine
For the staff who have not return the book. Fine will be calculated as Rs. 5 per
day.
Fine = 5 * (No. of days = Current Date � Expected return date), for others it
should be displayed as �
*/

/*3. List out all the staffs who are reporting to the same manager to whom staff 100060
reports to.*/

select * from staff_master

/*4. List out all the students along with the department who reads the same books which
the professors read
*/

select * from book_transaction
select * from student_master 

select bt.student_code,sm.student_name,sm.dept_code 
from book_transaction bt inner join student_master sm on (bt.student_code=sm.student_code)
where bt.student_code is not null and bt.staff_code is not null

/*5. List out all the authors who have written books on same category as written by
Author David Gladstone.
*/

select * from book_master
select book_pub_author from book_master
where book_category=(select book_category from book_master where book_pub_author='Author David Gladstone')

/*
6. Display the Student report Card for this year. The report Card should contain the
following information.
Student Code Student Name Department Name Total Marks Grade
Grade is calculated as follows. If a student has scored < 60 or has not attempted
an exam he is considered to an F
>80 - E
70-80 - A
60- 69 - B
*/
select sms.student_code,sms.student_name,dm.dept_name,(sm.subject1+sm.subject2+sm.subject3) as total,
case when
((sm.subject1+sm.subject2+sm.subject3)/3)<60 then 'F' 
when
((sm.subject1+sm.subject2+sm.subject3)/3)>80 then 'E'
when
((sm.subject1+sm.subject2+sm.subject3)/3) between 70 and 80 then 'A'
when
((sm.subject1+sm.subject2+sm.subject3)/3) between 60 and 69 then 'B'
End
as grade
from department_master dm inner join (student_master sms inner join student_marks sm on (sm.student_code=sm.student_code)) on (sms.dept_code=dm.dept_code)





--2.3 Indexes and Views

/* 1. Create a Filtered Index HumanResources.Employee table present in the
AdventureWorks database for the column EmployeeID. The index should cover all
the queries that uses EmployeeID for its search & that select only rows with
�Marketing Manager� for Title column.*/

select h.employeeid
from HumanResources.Employee h
where h.title='Marketing Manager';

Create nonclustered index dept_123
on HumanResources.Employee(EmployeeID)
where title='Marketing Manager';

select h.employeeid
from HumanResources.Employee h
where h.title='Marketing Manager';